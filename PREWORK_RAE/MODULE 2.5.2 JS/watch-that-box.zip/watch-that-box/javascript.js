document.getElementById("button1").onclick = myFunctionGrow;
document.getElementById("button2").onclick = myFunctionBlue;
document.getElementById("button3").onclick = myFunctionFade;
document.getElementById("button4").onclick = myFunctionReset;

function myFunctionGrow() {
    let objDocument = document.getElementById("box");
  
    let boxHeight = objDocument.clientHeight;
    boxHeight = boxHeight * 1.05;
  
    let boxWidth = objDocument.clientWidth;
    boxWidth = boxWidth * 1.05;
    document.getElementById("box").style.height = boxHeight + "px";
    document.getElementById("box").style.width = boxWidth + "px";
  }
  
  function myFunctionBlue() {
    let objDocument = document.getElementById("box");
    objDocument.style.background = "blue";
  }

  function myFunctionFade() {
    let objDocument = document.getElementById("box");
  
    let boxOpacity = objDocument.style.opacity;
    if (boxOpacity == "") {
        boxOpacity = 0.95;
    }
    else {
        boxOpacity = boxOpacity * 0.95;
    }
    document.getElementById("box").style.opacity = boxOpacity;
  }

function myFunctionReset() {

    let objDefaultStyleHeight = "150px";
    let objDefaultStyleWidth =  "150px"; 
    let objDefaultStyleBackgroundcolor = "orange"; 
    let objDefaultStyleMargin = "25px";
  
    document.getElementById("box").style.height = objDefaultStyleHeight;
    document.getElementById("box").style.width = objDefaultStyleWidth;
    document.getElementById("box").style.background = objDefaultStyleBackgroundcolor;
    document.getElementById("box").style.margin = objDefaultStyleMargin;
    document.getElementById("box").style.opacity = 1;
  }
